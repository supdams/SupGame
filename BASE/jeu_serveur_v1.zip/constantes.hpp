// constantes.hpp

#ifndef _CONSTANTES
#define _CONSTANTES


#define _NOUVEAU_CLIENT_		'N'
#define _BIENVENUE_ID_			'B'
#define _DECONNEXION_CLIENT_	'D'
#define	_MESSAGE_NORMAL_		'P'


#define _SEPARATEUR_PERSO_	'#'
#define _FIN_MESSAGE_		'$'


#define	_NB_CHAR_ID_		4

#define _NB_MAX_CHAT_		12
#define _MAXLEN_			2048
#define _MAXNOM_			12
#define _PORT_				8000

#define _TICK_INTERVAL_		10

#endif